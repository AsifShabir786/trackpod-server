Open folder in vs code
open terminal
run command 'npm install'
then 'npm start' for running it
and for testing of real data  use
http://localhost:9001/leads
and for live backend 
https://leads-crud-nodejs.vercel.app/leads